import { SearchComponent } from './components/search/search.component';
import { AddTeamComponent } from './components/add-team/add-team.component';
import { MatchInfoComponent } from './components/match-info/match-info.component';
import { AdminComponent } from './components/admin/admin.component';
import { AddMatchComponent } from './components/add-match/add-match.component';
import { SignupComponent } from './components/signup/signup.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  // localhost:4200
  {path: '', component:HomeComponent},
  // localhost:4200/login
  {path: 'login', component:LoginComponent},
  {path: 'signup', component:SignupComponent},
    // localhost:4200/x
  {path: 'x', component:SignupComponent},
  {path: 'addMatch', component:AddMatchComponent},
  {path: 'admin', component:AdminComponent},
  {path: 'match-info/:id', component:MatchInfoComponent},
  {path: 'edit-match/:id', component:AddMatchComponent},
  {path: 'addTeam', component: AddTeamComponent},
  {path: 'search', component: SearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
