import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-world-cup',
  templateUrl: './world-cup.component.html',
  styleUrls: ['./world-cup.component.css']
})
export class WorldCupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
