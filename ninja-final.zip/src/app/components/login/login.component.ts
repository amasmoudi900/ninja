import { UserService } from './../../services/user.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  x:string='Hello, you can ';
  path:string="assets/images/bg_1.jpg";
  loginForm:FormGroup;
  user:any={};
  constructor(
    private formBuilder:FormBuilder,
    private userService:UserService) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email:[''],
      pwd:['']
    });
  }

  login(){
    console.log('Here my user',this.user);
    this.userService.login(this.user).subscribe();
  }

}
